exports.ondefault=function(req,res)
{
res.send(app.use(___dirname+"./index.html"))
}

exports.onhello=function(req,res)
{
    var person=
    {
      name:"onkar",
      add:"pune",
      ph_no:524355
    };
    res.send(person);
}