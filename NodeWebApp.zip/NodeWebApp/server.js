var express=require("express");
var path=require("path");
var handlers=require("./handler");
var app=express();


app.use(express.static(path.join(__dirname,"public")));

app.get("/",handlers.ondefault);
app.get("/hello",handlers.onhello);

var onlisten=function()
{
    var host=server.address().address;
    var port=server.address().port;
    console.log("running on"+ host+""+port);
}
var server=app.listen(3000,onlisten);