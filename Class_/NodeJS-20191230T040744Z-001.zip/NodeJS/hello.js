
var  count=56;
count++;
var name="Welcome to Transflower!";
var product ={
	      title:"Lotus",
              description:"Worship flower",
 	      quantity:1000,
	      unitprice:10

	     }

console.log("Welcome to Browserless application");
console.log("Result" + count);
console.log(name);
console.log(product);
console.log(product.title);

