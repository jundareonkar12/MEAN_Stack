



//user defined function

/*var onDisplay=function(){
    console.log("MEAN full stack .....");
}
var onTimer=function(){

    console.log("Welcome to NodeJS");
}

setInterval(onTimer, 2000);
setInterval(onDisplay, 4000);
*/

setInterval(()=>{console.log("Welcome to Lambda....")}, 2000);

console.log("I am doing my job: Core Job....");

